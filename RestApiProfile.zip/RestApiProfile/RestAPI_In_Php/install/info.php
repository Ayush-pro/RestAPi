<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "RestApi", 
	'summary' => "Build a rest API with ProcessWire. Including JWT-Auth and a Vue SPA example", 
	'screenshot' => ""
	);
