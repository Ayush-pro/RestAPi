This file is here to ensure Git adds the dir to the repo. You may delete this file. 
