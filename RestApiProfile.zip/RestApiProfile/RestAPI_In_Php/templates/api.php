<?php namespace ProcessWire;

require "{$config->paths->templates}api/Router.php";
